<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>BMS</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('images/logo.png')); ?>">



<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/bootstrap/css/bootstrap.min.css')); ?>">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('DataTables/DataTables-1.13.4/css/jquery.dataTables.css')); ?>" />
<script type="text/javascript" src="<?php echo e(asset('DataTables/DataTables-1.13.4/js/jquery.dataTables.js')); ?>"></script>


<!-- Fontawesome CSS -->
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
<!-- Main CSS -->

        
    </head><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/config/head.blade.php ENDPATH**/ ?>
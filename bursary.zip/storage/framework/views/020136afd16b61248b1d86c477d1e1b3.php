<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('config.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <div class="header">
				<?php echo $__env->make('config.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul >
							<li class="menu-title"> 
								<!--<span>Main Menu</span>-->
							</li>
							<li > 
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-th-large"></i> <span>Dashboard</span></a>
							</li>
							<li > 
								<a href="<?php echo e(url('applications')); ?>"><i class="fa fa-file"></i> <span>Applications</span></a>
							</li>
							
							<li> 
								<a href="<?php echo e(route('applicants')); ?>"><i class="fa fa-list"></i> <span>Applicants</span></a>
							</li>
                            <li> 
								<a href="<?php echo e(url('beneficiaries')); ?>"><i class="fa fa-users"></i> <span>Beneficiaries</span></a>
							</li>
						
							<li > 
								<a href="<?php echo e(url('reports')); ?>"><i class="fa fa-shopping-cart"></i> <span>Bursary Reports</span></a>
							</li>
						
							<li class="submenu">
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-file"></i> <span>Reports</span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="<?php echo e(url('location_report')); ?>">Location Report</a></li>
									<li><a href="<?php echo e(url('sub_location_report')); ?>">Sub-location Report</a></li>
								</ul>
							</li>
				
							<li class="active"> 
								<a href="<?php echo e(url('users')); ?>"><i class="fa fa-user"></i> <span>Users</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('settings')); ?>"><i class="fa fa-cog"></i> <span>settings</span></a>
							</li>
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper mt-5">
			
                <div class="content container-fluid">

                	<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<!--<h3 class="page-title">Welcome Admin!</h3>-->
								<ul class="breadcrumb">
									<li class="breadcrumb-item active font-weight-bold" style="text-transform: uppercase;">Users</li>
								</ul>
							</div>
						</div>
					</div>
					
					


					<div class="row">
						<div class="container col-md-10">
                            
                            <?php if(session()->has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                     <span aria-hidden="true">&times;</span>
                                     </button>
                                     </div>
                            <?php endif; ?>
                            
                              
                              <?php if(session()->has('error')): ?>
                              <div class="alert alert-danger alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                  <span class="font-weight-bold"><?php echo e(session()->get('error')); ?></span>
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                       </button>
                                       </div>
                              <?php endif; ?>
                              
                            <a href="" class="btn btn-secondary" data-toggle="modal" data-target="#New">Add New User</a>
                            <div class="modal fade" id="New" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                           <h4 class="text-center">Add New USer</h4>
                                        </div>
                                        <div class="modal-body">
                                           <form method="post" action="<?php echo e(url('add_user')); ?>">
                                               <?php echo csrf_field(); ?>
                                               <label class="font-weight-bold">Enter Fullname :</label>
                                            <input type="text" name="name" class="form-control" id="" required >
                                           <label class="font-weight-bold">Enter Email :</label>
                                            <input type="email" name="email" class="form-control" id="" required >
                                            <label class="font-weight-bold">Enter Phone :</label> 
                                            <input type="number" name="phone" class="form-control" id="" required >
                                            <label class="font-weight-bold">Select Role :</label> 
                                            <select name="role" id="" class="form-control" required>
                                                <option>--select role--</option>
                                                <option>Admin</option>
                                                <option>Ass_admin</option>
                                             </select>
                                            <input type="submit" value="A D D" name="add" class="btn btn-success form-control mt-2">
                                           </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<!-- Revenue Chart -->
							
								<div class="card-body">
									<div id="line_graph">
									</div>
									<div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <td>#</td>
                                                    <td>Fullname</td>
                                                    <td>Email</td>
                                                    <td>Actions</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($data->id); ?></td>
                                                    <td><?php echo e($data->fullname); ?></td>
                                                    <td><?php echo e($data->email); ?></td>
                                                    <td>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                        <a href="" class="btn btn-primary" data-toggle="modal" data-target="#Modal<?php echo e($data->id); ?>">EDIT</a></div>
                                                         <!-- edit user modal -->
     <div class="modal fade" id="Modal<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                <h4 class="text-center">Edit User Details</h4>
             </div>
             <div class="modal-body">
                <form method="post" action="<?php echo e(url('edit_user/'.$data->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <label class="font-weight-bold">Enter Fullname :</label>
                 <input type="text" name="name" class="form-control" id="" required value="<?php echo e($data->fullname); ?>">
                <label class="font-weight-bold">Enter Email :</label>
                 <input type="email" name="email" class="form-control" id="" required value="<?php echo e($data->email); ?>">
                 <label class="font-weight-bold">Enter Phone :</label>
                 <input type="number" name="phone" class="form-control" id="" required value="<?php echo e($data->phone); ?>">
                 <label class="font-weight-bold">Enter Role :</label>
                 <select name="role" id="" class="form-control" required>
                    <option  selected><?php echo e($data->role); ?></option>
                    <option>--select role--</option>
                    <option>Admin</option>
                    <option>Ass_admin</option>
                 </select>
                 <input type="submit" value="E D I T" name="edit" class="btn btn-success form-control mt-2">
                </form>
             </div>
         </div>
     </div>
 </div>
                                                    <div class="col-md-6"><a href="" class="btn btn-secondary"  data-toggle="modal" data-target="#Change<?php echo e($data->id); ?>">Change Password</a></div></div></td>
                                                </tr>
                                                                                                     <!-- edit user modal -->
     <div class="modal fade" id="Change<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                   <h4 class="text-center">Change Password</h4>
                </div>
                <div class="modal-body">
                   <form method="post" action="<?php echo e(url('change_password/'.$data->id)); ?>">
                       <?php echo csrf_field(); ?>
                       <label class="font-weight-bold">Enter Current Password :</label>
                    <input type="password" name="current_pass" class="form-control" id="" required>
                   <label class="font-weight-bold">Enter New Password :</label>
                    <input type="password" name="new_pass" class="form-control" id="" required>
                    <label class="font-weight-bold">Re-Enter New Password :</label>
                    <input type="password" name="re_pass" class="form-control" id="" required>
                    <input type="submit" value="R E S E T" name="reset" class="btn btn-success form-control mt-2">
                   </form>
                </div>
            </div>
        </div>
    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
								</div>
							
							<!-- /Revenue Chart -->
							
						</div>
					</div>

				</div>

			</div>
			<!-- /Page Wrapper -->

			
        </div>
		<!-- /Main Wrapper -->
		<?php echo $__env->make('config.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
	
    
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('DataTables/DataTables-1.13.4/js/jquery.dataTables.js')); ?>"></script>
    <script>
    jQuery(document).ready(function($) {
        $('#sample').DataTable();
    } );
    </script>
</html><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/users.blade.php ENDPATH**/ ?>
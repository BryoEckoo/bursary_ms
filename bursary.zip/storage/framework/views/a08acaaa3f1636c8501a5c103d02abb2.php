<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('config.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <div class="header">
				<?php echo $__env->make('config.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul >
							<li class="menu-title"> 
								<!--<span>Main Menu</span>-->
							</li>
							<li > 
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-th-large"></i> <span>Dashboard</span></a>
							</li>
							<li > 
								<a href="<?php echo e(url('applications')); ?>"><i class="fa fa-file"></i> <span>Applications</span></a>
							</li>
							
							<li class="active"> 
								<a href="<?php echo e(route('applicants')); ?>"><i class="fa fa-list"></i> <span>Applicants</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('beneficiaries')); ?>"><i class="fa fa-users"></i> <span>Beneficiaries</span></a>
							</li>
						
							<li> 
								<a href="<?php echo e(url('reports')); ?>"><i class="fa fa-shopping-cart"></i> <span>Bursary Reports</span></a>
							</li>
						
							<li class="submenu">
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-file"></i> <span>Reports</span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="<?php echo e(url('location_report')); ?>">Location Report</a></li>
									<li><a href="<?php echo e(url('sub_location_report')); ?>">Sub-location Report</a></li>
								</ul>
							</li>
				
							<li> 
								<a href="<?php echo e(url('users')); ?>"><i class="fa fa-user"></i> <span>Users</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('settings')); ?>"><i class="fa fa-cog"></i> <span>settings</span></a>
							</li>
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
                <div class="content container-fluid">

                	<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<!--<h3 class="page-title">Welcome Admin!</h3>-->
								<ul class="breadcrumb">
									<li class="breadcrumb-item active">Applicants</li>
								</ul>
							</div>
						</div>
					</div>
					
					


					<div class="row">
						<div class="col-md-12">
						
							<!-- Revenue Chart -->
							<div class="card card-chart">
								
								<div class="card-body">
									<div id="line_graph">
                                        <?php if(session()->has('message')): ?>
                                        <div class="alert alert-warning alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
										<?php if(session()->has('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('success')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
                                    </div>
									<div class="table-responsive">
                                        <table class="table table-bordered table-striped" id="sample">
                                        <thead>
                                            <tr>
                                                <td class="font-weight-bold text-center">#</td>
                                                <td class="font-weight-bold text-center">Full Name</td>
                                                <td class="font-weight-bold text-center">Age</td>
                                                <td class="font-weight-bold text-center">School Level</td>
                                                <td class="font-weight-bold text-center">County</td>
                                                <td class="font-weight-bold text-center">Location</td>
                                                <td class="font-weight-bold text-center">Sub-location</td>
                                                <td class="font-weight-bold text-center">Actions</td>
                                            </tr>
                                        </thead>
                                        
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($val->id); ?></td>
                                                <td><?php echo e($val->student_fullname); ?></td>
                                                <td><?php echo e($val->age); ?></td>
                                                <td><?php echo e($val->school_level); ?></td>
                                                <td><?php echo e($val->county); ?></td>
                                                <td><?php echo e($val->location); ?></td>
                                                <td class=" font-weight-bold"><?php echo e($val->sub_location); ?></td>
                                                <td class="text-center"><a href="<?php echo e(url('edit')); ?>"class="btn btn-primary" data-toggle="modal" data-target="#Edit<?php echo e($val->student_fullname); ?>">Edit</a>
                                                
                                                <div id="Edit<?php echo e($val->student_fullname); ?>" class="modal fade" role="dialog">
                                                    <div class="modal-dialog">
                                                        <form method="post" action="<?php echo e(url('update/'.$val->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <!-- Modal content-->
                                                            <div class="modal-content">
                                        
                                                                <div class="modal-header" style="background: #398AD7; color: #fff;">
                                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                    <h4 class="modal-title">UPDATE</h4>
                                                                </div>
                                        
                                                                <div class="modal-body">
                                                                    <label for="" class="font-weight-bold">Fullname :</label>
                                                                    <input type="text" name="fullname" value="<?php echo e($val->student_fullname); ?>" class="form-control">
                                                                    <label for="" class="font-weight-bold">Age :</label>
                                                                    <input type="number" name="age" value="<?php echo e($val->age); ?>" class="form-control">
																	<label for="" class="font-weight-bold">Family Status :</label>
                                                                    <select name="family_status" id="" class="form-control">
																		<option selected><?php echo e($val->family_status); ?></option>
																		<option>--select status--</option>
																		<option>Rich</option>
																		<option>Average</option>
																		<option>Poor</option>
																		<option>Very-poor</option>
																		
																	 </select>
                                                                    <label for="" class="font-weight-bold">School Level :</label>
																	<select name="school_level" id="" class="form-control">
																		<option selected><?php echo e($val->school_level); ?></option>
																		<option>--select school-level--</option>
																		<option>Primary School</option>
																		<option>Secondary School</option>
																		<option>University/TVET/College</option>
																	 </select>
																	<label for="" class="font-weight-bold">School Name :</label>
                                                                    <select name="school_name" id="" class="form-control">
																		<option selected><?php echo e($val->school_name); ?></option>
																		<option>--select school--</option>
																		<option>Moi Girls High School</option>
																		<option>G.K High School</option>
																		<option>U.G High School</option>
																		<option>Umoja High School</option>
																		<option>Kapsoya Secondary School</option>
																	 </select>
                                                                    <label for="" class="font-weight-bold">County :</label>
                                                                    <input type="text" name="county" value="<?php echo e($val->county); ?>" class="form-control">
																	<label for="" class="font-weight-bold">Ward :</label>
																	<select name="ward" id="" class="form-control">
																		<option selected><?php echo e($val->ward); ?></option>
																		<option>--select ward--</option>
																		<option>Kimumu</option>
																		<option>Ainabkio</option>
																		<option>Moiben</option>
																	 </select>
                                                                    <label for="" class="font-weight-bold">Location :</label>
                                                                    <select name="location" id="" class="form-control">
																		<option selected><?php echo e($val->location); ?></option>
																		<option>--select location--</option>
																		<option>Boma</option>
																		<option>Mwanzo</option>
																		<option>Kipkaren</option>
																		<option>Langas</option>
																		<option>Jerusalem</option>
																		<option>Berlin</option>
																	 </select>
                                                                    <label for="" class="font-weight-bold">Sub Location :</label>
                                                                    <select name="sub_location" id="" class="form-control">
																		<option selected><?php echo e($val->sub_location); ?></option>
																		<option>--select sub_location--</option>
																		<option>Soy</option>
																		<option>Kiplombe</option>
																		<option>Ngurunga</option>
																		<option>Quinet</option>
																		<option>Kapsoya</option>
																	 </select>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" name="delete_acc" class="btn btn-danger">UPDATE</button>
                                                                        <button type="button" class="btn btn-default" data-dismiss="modal">CANCEL</button>
																	</div>
                                                                </div>
                                                        </form>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                            
                                            
                                            <div id="Modal<?php echo e($val->id); ?>" class="modal fade" role="dialog">
                                                <div class="modal-dialog">
                                                    <form method="post" action="<?php echo e(url('delete/'.$val->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                    
                                                            <div class="modal-header" style="background: #398AD7; color: #fff;">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 class="modal-title">Delete</h4>
                                                            </div>
                                    
                                                            <div class="modal-body">
                                                                <p>
                                                                    <div class="alert alert-danger">Are you Sure you want Delete.... <strong><?php echo e($val->student_fullname); ?>?</strong></p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit" name="delete_acc" class="btn btn-danger">YES</button>
                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">NO</button>
                                                                </div>
                                                            </div>
                                                    </form>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        
                                        </table>
                                    </div>
								</div>
							</div>
							<!-- /Revenue Chart -->
							
						</div>
					</div>

				</div>

                

			</div>
			<!-- /Page Wrapper -->

			
        </div>
		<!-- /Main Wrapper -->
		<?php echo $__env->make('config.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
	
    
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('DataTables/DataTables-1.13.4/js/jquery.dataTables.js')); ?>"></script>
    <script>
    jQuery(document).ready(function($) {
        $('#sample').DataTable();
    } );
    </script>
</html>
<?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/applicants.blade.php ENDPATH**/ ?>
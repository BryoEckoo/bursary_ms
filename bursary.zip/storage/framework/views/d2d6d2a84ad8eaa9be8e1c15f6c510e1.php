<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('config.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <div class="header">
				<?php echo $__env->make('config.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul >
							<li class="menu-title"> 
								<!--<span>Main Menu</span>-->
							</li>
							<li > 
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-th-large"></i> <span>Dashboard</span></a>
							</li>
							<li class="active"> 
								<a href="<?php echo e(url('applications')); ?>"><i class="fa fa-users"></i> <span>Applications</span></a>
							</li>
							
							<li> 
								<a href="<?php echo e(route('applicants')); ?>"><i class="fa fa-map-marker-alt"></i> <span>Applicants</span></a>
							</li>
						
							<li> 
								<a href="<?php echo e(url('reports')); ?>"><i class="fa fa-shopping-cart"></i> <span>Bursary Reports</span></a>
							</li>
						
							<li class="submenu">
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-file"></i> <span>Reports</span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="<?php echo e(url('location_report')); ?>">Location Report</a></li>
									<li><a href="<?php echo e(url('sub_location_report')); ?>">Sub-location Report</a></li>
								</ul>
							</li>
				
							<li> 
								<a href="<?php echo e(url('users')); ?>"><i class="fa fa-user"></i> <span>Users</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('settings')); ?>"><i class="fa fa-cog"></i> <span>settings</span></a>
							</li>
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
                <div class="content container-fluid">

                	<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<!--<h3 class="page-title">Welcome Admin!</h3>-->
								<ul class="breadcrumb">
									<li class="breadcrumb-item active">Applications</li>
								</ul>
							</div>
						</div>
					</div>
					
					


					<div class="row">
						<div class="col-md-12">
						
							<!-- Revenue Chart -->
							<div class="card card-chart">
								
								<div class="card-body">
									<div id="line_graph">
										<?php if(session()->has('message')): ?>
                                        <div class="alert alert-warning alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
										<?php if(session()->has('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('success')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
									</div>
									<div class="table-responsive">
										<table class="table table-bordered table-striped" id="sample">
										<thead>
											<tr>
												<td class="font-weight-bold text-center">#</td>
												<td class="font-weight-bold text-center">REF-NO.</td>
												<td class="font-weight-bold text-center">Applicant Name</td>
												<td class="font-weight-bold text-center">School Type</td>
												<td class="font-weight-bold text-center">Location</td>
                                                <td class="font-weight-bold text-center">Application Date</td>
												<td class="font-weight-bold text-center">Status</td>
												<td class="font-weight-bold text-center">Actions</td>
											</tr>
										</thead>
										
										<tbody>
											<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($val->id); ?></td>
												<td><?php echo e($val->reference_number); ?></td>
												<td><?php echo e($val->student_fullname); ?></td>
                                                <td><?php echo e($val->school_type); ?></td>
												<td><?php echo e($val->location); ?></td>
                                                <td><?php echo e($val->today_date); ?></td>
												<td class="text-warning font-weight-bold"><?php echo e($val->status); ?></td>
												<td class="text-center"><a href=""class="btn btn-primary" data-toggle="modal" data-target="#Edit<?php echo e($val->reference_number); ?>">Edit</a>
													<div class="modal fade" id="Edit<?php echo e($val->reference_number); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
														aria-hidden="true">
														<div class="modal-dialog" role="document">
															<div class="modal-content">
																<div class="modal-header">
																   <h4 class="text-center">EDIT APPLICATION</h4>
																</div>
																<div class="modal-body">
																   <form method="post" action="<?php echo e(url('edit/'.$val->reference_number)); ?>">
																	   <?php echo csrf_field(); ?>
																	   <label class="font-weight-bold">Reference Number :</label>
																	<input type="text" name="ref" class="form-control" id="" readonly value="<?php echo e($val->reference_number); ?>">
																   <label class="font-weight-bold">UPI/ADM/REG No :</label>
																	<input type="text" name="upi_reg" class="form-control" id="" required value="<?php echo e($val->adm_upi_reg_no); ?>">
																	<label class="font-weight-bold">Fullname :</label> 
																	<input type="text" name="name" class="form-control" id="" required value="<?php echo e($val->student_fullname); ?>">
																	
																	<label class="font-weight-bold">School type :</label> 
																	<select name="school_type" id="" class="form-control">
																		<option selected><?php echo e($val->school_type); ?></option>
																		<option>--select role--</option>
																		<option>Primary School</option>
																		<option>Secondary School</option>
																		<option>University School</option>
																	 </select>
																	 <label class="font-weight-bold">School name :</label> 
																	<input type="text" name="school_name" class="form-control" id="" required value="<?php echo e($val->school_name); ?>">
																	<label class="font-weight-bold">Location :</label> 
																	<select name="location" id="" class="form-control" required>
																		<option selected><?php echo e($val->location); ?></option>
																		<option>--select role--</option>
																		<option>Jerusalem</option>
																		<option>Munyaka</option>
																		<option>Ziwa</option>
																		<option>Ilula</option>
																		<option>Block10</option>
																		<option>Subaru</option>
																		<option>Vet</option>
																		<option class="">Langas</option>
																	 </select>
																	 <label class="font-weight-bold">Bank name :</label> 
																	<input type="text" name="bank" class="form-control" id="" value="moi">
																	<label class="font-weight-bold">School Account no :</label> 
																	<input type="number" name="account" class="form-control" id="" required value="<?php echo e($val->account_no); ?>">
																	<input type="submit" value="E D I T" name="edit" class="btn btn-success form-control mt-2">
																   </form>
																</div>
															</div>
														</div>
													</div>
												
												<a href=""class="btn btn-success" data-toggle="modal" data-target="#Approve<?php echo e($val->id); ?>">Approve</a>
											
											<div id="Approve<?php echo e($val->id); ?>" class="modal fade" role="dialog">
												<div class="modal-dialog">
													<form method="post" action="<?php echo e(url('approve_application/'.$val->id)); ?>">
														<?php echo csrf_field(); ?>
														<!-- Modal content-->
														<div class="modal-content">
									
															<div class="modal-header" style="background: #398AD7; color: #fff;">
																<button type="button" class="close" data-dismiss="modal">&times;</button>
																<h4 class="modal-title">Approve</h4>
															</div>
									
															<div class="modal-body">
																<p>
																	<div class="alert alert-warning">Are you Sure you want Approve.... <strong><?php echo e($val->reference_number); ?>?</strong></p>
																</div>
																<div class="modal-footer">
																	<button type="submit" name="approve" class="btn btn-success">YES</button>
																	<button type="button" class="btn btn-default" data-dismiss="modal">NO</button>
																</div>
															</div>
													</form>
													</div>
												</div>
											</td>
											
											<div id="Modal<?php echo e($val->id); ?>" class="modal fade" role="dialog">
                                                <div class="modal-dialog">
                                                    <form method="post" action="<?php echo e(url('delete_application/'.$val->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                    
                                                            <div class="modal-header" style="background: #398AD7; color: #fff;">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 class="modal-title">Delete</h4>
                                                            </div>
                                    
                                                            <div class="modal-body">
                                                                <p>
                                                                    <div class="alert alert-danger">Are you Sure you want Delete.... <strong><?php echo e($val->reference_number); ?>?</strong></p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit" name="delete_acc" class="btn btn-danger">YES</button>
                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">NO</button>
                                                                </div>
                                                            </div>
                                                    </form>
                                                    </div>
                                                </div>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
										
										</table>
									</div>
								</div>
							</div>
							<!-- /Revenue Chart -->
							
						</div>
					</div>

				</div>

			</div>
			<!-- /Page Wrapper -->

			
        </div>
		<!-- /Main Wrapper -->
		<?php echo $__env->make('config.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
	
    
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('DataTables/DataTables-1.13.4/js/jquery.dataTables.js')); ?>"></script>
    <script>
    jQuery(document).ready(function($) {
        $('#sample').DataTable();
    } );
    </script>
</html><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/applications.blade.php ENDPATH**/ ?>
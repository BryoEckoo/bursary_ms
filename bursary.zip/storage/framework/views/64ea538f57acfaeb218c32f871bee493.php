<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('config.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <div class="header">
				<?php echo $__env->make('config.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul >
							<li class="menu-title"> 
								<!--<span>Main Menu</span>-->
							</li>
							<li > 
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-th-large"></i> <span>Dashboard</span></a>
							</li>
							<li > 
								<a href="<?php echo e(url('applications')); ?>"><i class="fa fa-file"></i> <span>Applications</span></a>
							</li>
							
							<li> 
								<a href="<?php echo e(route('applicants')); ?>"><i class="fa fa-list"></i> <span>Applicants</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('beneficiaries')); ?>"><i class="fa fa-users"></i> <span>Beneficiaries</span></a>
							</li>
							<li > 
								<a href="<?php echo e(url('reports')); ?>"><i class="fa fa-shopping-cart"></i> <span>Bursary Reports</span></a>
							</li>
						
							<li class="submenu active">
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-file"></i> <span>Reports</span> <span class="menu-arrow"></span></a>
								<ul>
									<li class="active"><a href="<?php echo e(url('location_report')); ?>">Location Report</a></li>
									<li><a href="<?php echo e(url('sub_location_report')); ?>">Sub-location Report</a></li>
								</ul>
							</li>
				
							<li> 
								<a href="<?php echo e(url('users')); ?>"><i class="fa fa-user"></i> <span>Users</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('settings')); ?>"><i class="fa fa-cog"></i> <span>settings</span></a>
							</li>
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
                <div class="content container-fluid">

                	<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<!--<h3 class="page-title">Welcome Admin!</h3>-->
								<ul class="breadcrumb">
									<li class="breadcrumb-item active font-weight-bold" style="text-transform: uppercase;">Location Reports</li>
								</ul>
							</div>
						</div>
					</div>
					
					


					<div class="row">
						<div class="container col-md-8">
						
							<!-- Revenue Chart -->
							<div class="card card-chart">
								
								<div class="card-body">
									<div id="line_graph">
										<?php if(session()->has('message')): ?>
                                        <div class="alert alert-warning alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
									</div>
									<form action="<?php echo e(url('print_location')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <label>Select Location :</label>
                                        <select name="location" id="" class="form-control">
											<option>-select location-</option>
                                            <option>Munyaka</option>
                                            <option>Ilula</option>
                                            <option>Marura</option>
                                            <option>Block 10</option>
                                            <option>Silas</option>
                                            <option>Jerusalem</option>
                                        </select>
                                        <input type="submit" value="PRINT" class="btn btn-warning mt-2">
                                    </form>
								</div>
							</div>
							<!-- /Revenue Chart -->
							
						</div>
					</div>

				</div>

			</div>
			<!-- /Page Wrapper -->

			
        </div>
		<!-- /Main Wrapper -->
		<?php echo $__env->make('config.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
	
    
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('DataTables/DataTables-1.13.4/js/jquery.dataTables.js')); ?>"></script>
    <script>
    jQuery(document).ready(function($) {
        $('#sample').DataTable();
    } );
    </script>
</html><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/location_report.blade.php ENDPATH**/ ?>
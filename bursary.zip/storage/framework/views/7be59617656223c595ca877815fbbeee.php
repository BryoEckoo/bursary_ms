<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <script src=<?php echo e(asset('bootstrap/jquery/jquery-3.5.1.min.js')); ?>></script>
    <title>Login page-students:</title>
</head>
<body>
    <div class="container col-md-8" style="margin-top: 20vh">
        <div class="row" style="border: .1px light black">
        <div class="col-md-6">
            
            <div class="card-header jalign-item-center" style="background-image: url('images/logo.png');background-position:center;background-repeat:no-repeat;height:50vh">
                
                <h4 class="text-center font-weight-bold">LOGIN HERE</h4>
            </div>
            </div>
            <div class="col-md-6" style="margin-top: 6vh">
            <div class="card-body">
                <?php if(session()->has('message')): ?>
                <div class="alert alert-warning alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                    <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                         </button>
                         </div>
                <?php endif; ?>
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                    <span class="font-weight-bold"><?php echo e(session()->get('success')); ?></span>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                         </button>
                         </div>
                <?php endif; ?>
                <?php if($errors->has('email_reset')): ?>
                <div class="alert alert-danger alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                    <span class="font-weight-bold"><?php echo e($errors->first('email_reset')); ?></span>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                         </button>
                         </div>
                 <?php endif; ?>
                <form method="POST" action="<?php echo e(url('students/login_req')); ?>">
                    <?php echo csrf_field(); ?>
                <label class="font-weight-bold">Enter Email address :</label>
                <input type="text" name="email" class="form-control" id="" placeholder="example@admin.com" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span><br>
                <?php endif; ?>
                <label class="font-weight-bold">Enter Password :</label>
                <input type="password" name="password" class="form-control" id="" placeholder="********">
                <?php if($errors->has('password')): ?>
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span><br>
                <?php endif; ?>
                <input type="submit" class="btn btn-primary mt-2" value="LOGIN">
                </form>
                <div class="row justify-content-between">
                   <p class="mt-5">If not Registered Click <a href="<?php echo e(url('students/register')); ?>"> Here</a></p>
                   <a href="" data-toggle="modal" data-target="#Modal" class="mt-5">Forgot Password?</a>
            </div>
            </div>
        </div>
    </div>

     <!-- reset password modal -->
     <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                <h4 class="text-center">Reset Password</h4>
             </div>
             <div class="modal-body">
                <form method="post" action="<?php echo e(url('reset_password')); ?>">
                    <?php echo csrf_field(); ?>
                <label class="font-weight-bold">Enter Email :</label>
                 <input type="email" name="email" class="form-control" id="" required>
                 
                 <input type="submit" value="Reset" name="reset" class="btn btn-primary mt-2">
                </form>
             </div>
         </div>
     </div>
 </div>
</body>
<script src=<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>></script>
<script src=<?php echo e(asset('bootstrap/popper/popper.min.js')); ?>></script>
<script src=<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>></script>
</html><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/students/login.blade.php ENDPATH**/ ?>
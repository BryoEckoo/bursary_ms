<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bursary Management System</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/text.css')); ?>">
    <script src=<?php echo e(asset('bootstrap/jquery/jquery-3.5.1.min.js')); ?>></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
		<div class="heade">
			<a href="<?php echo e(url('/')); ?>" class="home" style="text-decoration: none" onmouseover="this.style.color='white'" onmouseout="this.style.color='lime'">B-M-S</a>
		</div>
		 <button class="navbar-toggler bg-dark" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
			<div class="collapse navbar-collapse" id="navbarNav">
	       <ul class="navbar-nav ml-auto pl-5 pr-5 mr-5">
				<li class="nav-item active mr-5 p-3 " style="">
					<a class="nav-link font-weight-bold" href="<?php echo e(url('/')); ?>" style="">Home</a>
				</li>
				<li class="nav-item mr-5 p-3">
					<a class="nav-link font-weight-bold" href="<?php echo e(url('applications')); ?>" style="">Applications</a>
				</li>
				<li class="nav-item mr-5 p-3">
					<a class="nav-link font-weight-bold" href="<?php echo e(url('applicants')); ?>" style="">Applicants</a>
				</li>
				<li class="nav-item mr-5 p-3">
					<a class="nav-link font-weight-bold"  href="<?php echo e(url('settings')); ?>" style="">Settings</a>
				</li>
                <li class="nav-item mr-5 p-3">
					<a class="nav-link font-weight-bold"  href="<?php echo e(url('logout')); ?>" style="color:white">Dan@ndong</a>
				</li>
                <li class="nav-item mr-5 p-3">
					<a class="nav-link font-weight-bold"  href="<?php echo e(url('logout')); ?>" style="">Logout</a>
				</li>
                <li class="nav-item mr-5 p-3">
					<a class="nav-link font-weight-bold"  href="<?php echo e(url('login')); ?>" style="">Login</a>
				</li>
			</ul>
</div>
</nav>
<div class="container-fluid">
    <div class="col-md-4 mt-5">
        <div class="card">
            <div class="card-header">
                <h4 class="text-center font-weight-bold">Add New Applicants</h4>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <?php echo csrf_field(); ?>
                <label for="" class="font-weight-bold">First Name :</label>
                <input type="text" name="first_name" class="form-control" id="">
                <label for="" class="font-weight-bold">Second Name :</label>
                <input type="text" name="second_name" class="form-control" id="">
                <label for="" class="font-weight-bold">Parent :</label>
                <input type="text" name="Parent/Guardian" class="form-control" id="">
                <label for="" class="font-weight-bold">ID No :</label>
                <input type="text" name="Id_no" class="form-control" id="">
                <label for="" class="font-weight-bold">Phone :</label>
                <input type="text" name="phone" class="form-control" id="">
                <label for="" class="font-weight-bold">Location :</label>
                <input type="text" name="location" class="form-control" id="">
                <input type="submit" class="btn btn-primary mt-2" value="Add New">
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Logo -->
<div class="header-left">
    <a href="dashboard" class="logo">
        <img src="assets/img/UGC_Logo.png" alt="Logo">
    </a>
    <a href="dashboard" class="logo logo-small">
        <img src="assets/img/UGC_Logo.png" alt="Logo" width="30" height="30">
    </a>
</div>
<!-- /Logo -->

<a href="javascript:void(0);" id="toggle_btn">
    <i class="fas fa-align-left"></i>
</a>


    <label style="font-weight: 900; margin-top: 1%; color: #0f893b; font-size: 25px; margin-left: 7%;">COUNTY GOVERNMENT OF UASIN GISHU</label>
    &emsp;&emsp;&emsp;
    


<!-- Search Bar -->
<!--<div class="top-nav-search">
    <form>
        <input type="text" class="form-control" placeholder="Search here">
        <button class="btn" type="submit"><i class="fas fa-search"></i></button>
    </form>
</div>-->
<!-- /Search Bar -->

<!-- Mobile Menu Toggle -->
<a class="mobile_btn" id="mobile_btn">
    <i class="fas fa-bars"></i>
</a>
<!-- /Mobile Menu Toggle -->

<!-- Header Right Menu -->
<ul class="nav user-menu">

    <!-- Notifications -->
    <!--<li class="nav-item dropdown noti-dropdown">
        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
            <i class="far fa-bell"></i> <span class="badge badge-pill">3</span>
        </a>
        <div class="dropdown-menu notifications">
            <div class="topnav-dropdown-header">
                <span class="notification-title">Notifications</span>
                <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
            </div>
            <div class="noti-content">
                <ul class="notification-list">
                    <li class="notification-message">
                        <a href="#">
                            <div class="media">
                                <span class="avatar avatar-sm">
                                    <img class="avatar-img rounded-circle" alt="User Image" src="assets/img/profiles/avatar-02.jpg">
                                </span>
                                <div class="media-body">
                                    <p class="noti-details"><span class="noti-title">Carlson Tech</span> has approved <span class="noti-title">your estimate</span></p>
                                    <p class="noti-time"><span class="notification-time">4 mins ago</span></p>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li class="notification-message">
                        <a href="#">
                            <div class="media">
                                <span class="avatar avatar-sm">
                                    <img class="avatar-img rounded-circle" alt="User Image" src="assets/img/profiles/avatar-11.jpg">
                                </span>
                                <div class="media-body">
                                    <p class="noti-details"><span class="noti-title">International Software Inc</span> has sent you a invoice in the amount of <span class="noti-title">$218</span></p>
                                    <p class="noti-time"><span class="notification-time">6 mins ago</span></p>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li class="notification-message">
                        <a href="#">
                            <div class="media">
                                <span class="avatar avatar-sm">
                                    <img class="avatar-img rounded-circle" alt="User Image" src="assets/img/profiles/avatar-17.jpg">
                                </span>
                                <div class="media-body">
                                <p class="noti-details"><span class="noti-title">John Hendry</span> sent a cancellation request <span class="noti-title">Apple iPhone XR</span></p>
                                <p class="noti-time"><span class="notification-time">8 mins ago</span></p>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li class="notification-message">
                        <a href="#">
                            <div class="media">
                                <span class="avatar avatar-sm">
                                    <img class="avatar-img rounded-circle" alt="User Image" src="assets/img/profiles/avatar-13.jpg">
                                </span>
                                <div class="media-body">
                                    <p class="noti-details"><span class="noti-title">Mercury Software Inc</span> added a new product <span class="noti-title">Apple MacBook Pro</span></p>
                                    <p class="noti-time"><span class="notification-time">12 mins ago</span></p>
                                </div>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="topnav-dropdown-footer">
                <a href="#">View all Notifications</a>
            </div>
        </div>
    </li>-->
    <!-- /Notifications -->
    
    <!-- User Menu -->
    <li class="nav-item dropdown has-arrow">
        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
            <span class="user-img"><img class="rounded-circle" src="assets/img/profiles/avatar-01.jpg" width="31" alt="Ryan Taylor"></span>
        </a>
        <div class="dropdown-menu">
            <div class="user-header">
                <div class="avatar avatar-sm">
                    <img src="assets/img/profiles/avatar-01.jpg" alt="User Image" class="avatar-img rounded-circle">
                </div>
                <div class="user-text">

                    
                </div>
            </div>
            <a class="dropdown-item" href="profile">My Profile</a>
            
            
            <a class="dropdown-item" href="logout">Logout</a>
        </div>
    </li>
    <!-- /User Menu -->
    
</ul>
<!-- /Header Right Menu -->

<style type="text/css">
	span{
		font-size: 14px;
	}
</style>
<div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul >
							<li class="menu-title"> 
								<!--<span>Main Menu</span>-->
							</li>
							<li class="active"> 
								<a href="dashboard"><i class="fas fa-th-large"></i> <span>Dashboard</span></a>
							</li>
							<li> 
								<a href="farm_produce"><i class="fas fa-seedling"></i> <span>Farm Produce</span></a>
							</li>
							<li> 
								<a href="market_names"><i class="fas fa-map-marker-alt"></i> <span>Markets</span></a>
							</li>
							<li> 
								<a href="county_details"><i class="fas fa-list-alt"></i> <span>County Details</span></a>
							</li>
	
							<li> 
								<a href="vehicle_types"><i class="fas fa-car"></i> <span>Vehicle Types</span></a>
							</li>
							<li> 
								<a href="main_market_prices"><i class="fas fa-coins"></i> <span>Main Market Prices</span></a>
							</li>
							
							<li class="submenu">
								<a href="#"><i class="fas fa-database"></i> <span>Main Market Data</span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="main_market_entry">Entry</a></li>
									<li><a href="main_market_exit">Exit</a></li>
								</ul>
							</li>
							<li> 
								<a href="retail_prices"><i class="fas fa-shopping-cart"></i> <span>Retail Market Prices</span></a>
							</li>

							<li class="submenu">
								<a href="#"><i class="fas fa-file"></i> <span>Reports</span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="main_market_monthly_report">Main Market Monthly Report</a></li>
									<li><a href="main_market_yearly_report">Main Market Yearly Report</a></li>
									<li><a href="retail_market_monthly_report">Retail Market Monthly Report</a></li>
									<li><a href="retail_market_yearly_report">Retail Market Yearly Report</a></li>
								</ul>
							</li>
					
							<li> 
								<a href="users"><i class="fas fa-user"></i> <span>Users</span></a>
							</li>
							
							
							

							

							

						</ul>
					</div>
                </div>
            </div>
</body>
<script src=<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>></script>
<script src=<?php echo e(asset('bootstrap/popper/popper.min.js')); ?>></script>
<script src=<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>></script>
<script src="">
    // Hide submenus
$('#body-row .collapse').collapse('hide'); 

// Collapse/Expand icon
$('#collapse-icon').addClass('fa-angle-double-left'); 

// Collapse click
$('[data-toggle=sidebar-colapse]').click(function() {
    SidebarCollapse();
});

function SidebarCollapse () {
    $('.menu-collapsed').toggleClass('d-none');
    $('.sidebar-submenu').toggleClass('d-none');
    $('.submenu-icon').toggleClass('d-none');
    $('#sidebar-container').toggleClass('sidebar-expanded sidebar-collapsed');
    
    // Treating d-flex/d-none on separators with title
    var SeparatorTitle = $('.sidebar-separator-title');
    if ( SeparatorTitle.hasClass('d-flex') ) {
        SeparatorTitle.removeClass('d-flex');
    } else {
        SeparatorTitle.addClass('d-flex');
    }
    
    // Collapse/Expand icon
    $('#collapse-icon').toggleClass('fa-angle-double-left fa-angle-double-right');
}
</script>
</html><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('config.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
	
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <div class="header">
				<?php echo $__env->make('config.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
			<!-- /Header -->
			
			<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul >
							<li class="menu-title"> 
								<!--<span>Main Menu</span>-->
							</li>
							<li > 
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-th-large"></i> <span>Dashboard</span></a>
							</li>
							<li > 
								<a href="<?php echo e(url('applications')); ?>"><i class="fa fa-file"></i> <span>Applications</span></a>
							</li>
							
							<li> 
								<a href="<?php echo e(route('applicants')); ?>"><i class="fa fa-list"></i> <span>Applicants</span></a>
							</li>

							<li class="active"> 
								<a href="<?php echo e(url('beneficiaries')); ?>"><i class="fa fa-users"></i> <span>Beneficiaries</span></a>
							</li>
						
							<li> 
								<a href="<?php echo e(url('reports')); ?>"><i class="fa fa-shopping-cart"></i> <span>Bursary Reports</span></a>
							</li>
						
							<li class="submenu">
								<a href="<?php echo e(url('index')); ?>"><i class="fa fa-file"></i> <span>Reports</span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="<?php echo e(url('location_report')); ?>">Location Report</a></li>
									<li><a href="<?php echo e(url('sub_location_report')); ?>">Sub-location Report</a></li>
								</ul>
							</li>
				
							<li> 
								<a href="<?php echo e(url('users')); ?>"><i class="fa fa-user"></i> <span>Users</span></a>
							</li>
							<li> 
								<a href="<?php echo e(url('settings')); ?>"><i class="fa fa-cog"></i> <span>settings</span></a>
							</li>
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
                <div class="content container-fluid">

                	<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<!--<h3 class="page-title">Welcome Admin!</h3>-->
								<ul class="breadcrumb">
									<li class="breadcrumb-item active">Beneficiaries List Documents</li>
								</ul>
							</div>
						</div>
					</div>
					
					


					<div class="row">
						<div class="col-md-12">
						
							<!-- Revenue Chart -->
                            <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#New">Add New Beneficiary Document</a>
                            <a href="" class="btn btn-secondary mb-3" data-toggle="modal" data-target="#Print">Print Beneficiary List</a>
							
							<div class="modal fade" id="Print" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
							aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
									   <h4 class="text-center">Print Beneficiary List</h4>
									</div>
									<div class="modal-body">
									   <form method="post" action="<?php echo e(url('print_beneficiary')); ?>" >
										   <?php echo csrf_field(); ?>
										   <label class="font-weight-bold">Select Year Below :</label>
										<select name="year" class="form-control" id="">
											<option value="">-Select Year-</option>
											<?php 
											
											$years = range(2020, strftime("%Y",time()));
											foreach ($years as $key) :
							
												?>
												<option><?php echo $key;?></option>
											<?php endforeach ?>
										</select>
										<?php if($errors->has('year')): ?>
										<span class="text-danger"><?php echo e($errors->first('year')); ?></span><br>
										<?php endif; ?>
										<label for="" class="font-weight-bold">Location : (Optional)</label>
										<select name="location" id="" class="form-control font-weight-bold">
											<option value="">-Select Location Here-</option>
											<option>Munyaka</option>
                                            <option>Silas</option>
                                            <option>Ilula</option>
                                            <option>Block 10</option>
                                            <option>Marura</option>
										</select>
										
										<input type="submit" value="P R I N T" name="print" class="btn font-weight-bold text-white btn-success form-control mt-2">
									   </form>
									</div>
								</div>
							</div>
						</div>
							
                            <div class="modal fade" id="New" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                           <h4 class="text-center">Upload New Beneficiary Document</h4>
                                        </div>
                                        <div class="modal-body">
                                           <form method="post" action="<?php echo e(url('upload')); ?>" enctype="multipart/form-data">
                                               <?php echo csrf_field(); ?>
                                               <label class="font-weight-bold">Enter Document Name :</label>
                                            <input type="text" name="document_name" placeholder="Enter the document name" class="form-control" id="" required >
                                            <?php if($errors->has('document_name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('document_name')); ?></span><br>
                                            <?php endif; ?>
                                           <label class="font-weight-bold">select Document :</label>
                                            <input type="file" name="document" class="form-control" id="" placeholder="choose a document" required >
                                            <?php if($errors->has('document')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('document')); ?></span><br>
                                            <?php endif; ?>
                                            <input type="submit" value="U P L O A D" name="upload" class="btn btn-success form-control mt-2">
                                           </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="card card-chart">
								
								<div class="card-body">
									<div id="line_graph">
                                        <?php if(session()->has('message')): ?>
                                        <div class="alert alert-warning alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
										<?php if(session()->has('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show text-center"  role="alert" style="position:sticky">
                                            <span class="font-weight-bold"><?php echo e(session()->get('success')); ?></span>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                 <span aria-hidden="true">&times;</span>
                                                 </button>
                                                 </div>
                                        <?php endif; ?>
                                        
                                    </div>
									<div class="table-responsive">
                                        <table class="table table-bordered table-striped" id="sample">
                                        <thead>
                                            <tr>
                                                <td class="font-weight-bold text-center">#</td>
                                                <td class="font-weight-bold text-center">Document Name</td>
                                                <td class="font-weight-bold text-center">Document</td>
                                                <td class="font-weight-bold text-center">Updated at</td>
                                                <td class="font-weight-bold text-center">Uploaded By</td>
                                                <td class="font-weight-bold text-center">Actions</td>
                                            </tr>
                                        </thead>
                                        
                                        <tbody>
                                           <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($data->id); ?></td>
                                                <td><?php echo e($data->document_name); ?></td>
                                                <td><?php echo e($data->document); ?></td>
                                                <td><?php echo e($data->updated_at); ?></td>
                                                <td><?php echo e($data->uploaded_by); ?></td>
                                                <td class="justify-content-between">
                                                    <a href="<?php echo e(url('download/'.$data->document)); ?>" class="btn btn-warning">DOWNLOAD</a>
                                                    <a href="" class="btn btn-secondary">View</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        
                                        </table>
                                    </div>
								</div>
							</div>
							<!-- /Revenue Chart -->
							
						</div>
					</div>

				</div>

                

			</div>
			<!-- /Page Wrapper -->

			
        </div>
		<!-- /Main Wrapper -->
		<?php echo $__env->make('config.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
	
    
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('DataTables/DataTables-1.13.4/js/jquery.dataTables.js')); ?>"></script>
    <script>
    jQuery(document).ready(function($) {
        $('#sample').DataTable();
    } );
    </script>
</html>
<?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/beneficiaries.blade.php ENDPATH**/ ?>
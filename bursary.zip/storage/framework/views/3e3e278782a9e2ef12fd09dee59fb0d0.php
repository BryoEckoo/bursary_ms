<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>send mail to applicants</title>
</head>
<body>
    <?php echo e($name); ?>

</body>
</html><?php /**PATH E:\xampp\htdocs\nrs_projects\bursary\resources\views/sendMail.blade.php ENDPATH**/ ?>